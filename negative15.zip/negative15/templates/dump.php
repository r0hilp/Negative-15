<!--
* dump.php
* Dumps data of a variable. Same as PSET7 
* Negative 15  
-->
<!DOCTYPE html>

<html>

    <head>
        <title>dump</title>
    </head>

    <body>
        <pre><?php print_r($variable); ?></pre>
    </body>

</html>
