DELTE


<div class="smallvspace"></div>
<div class = "box">
    <h1> Choose an Option </h1>
    <div>
    <a href="make.php"><button class="myButton">Make a meal</button></a>
    </div>
    <div class="smallvspace"></div>
    <div>
    <a href="menu.php"><button class="myButton">Today's menu</button></a>
    </div>
    <div class="smallvspace"></div>
    <div>
    <a href="history.php"><button class="myButton">Meal History</button></a>
    </div>
    <div class="smallvspace"></div>
    <div>
    <a href="instructions.php"><button class="myButton">Instructions</button></a>
    </div>
    <div class="smallvspace"></div>
    <div>
    <a href="logout.php"><button class="myButton">Log Out</button></a>
    </div>
</div>


<table>
    <!--
    <tr>
            <th>Name</th>
            <th>Symbol</th>
            <th>Shares</th> 
            <th>Price</th>
            <th>Current Value</th>
    </tr>-->
    <!-- TODO
    <?php foreach ($positions as $position): ?>
        <tr>
            <td><?= $position["name"] ?></td>
            <td><?= $position["symbol"] ?></td>
            <td><?= $position["shares"] ?></td>
            <td><?= number_format($position["price"], 2, '.', '') ?></td>
            <td><?= number_format($position["price"] * $position["shares"], 2, '.', '') ?></td>
        </tr>
    <?php endforeach ?>


        <tr>
            <td>CASH</td>
            <td> </td>
            <td> </td>
            <td> </td>
            <td><?= number_format($cash["cash"], 2, '.', '') ?></td>
        </tr>
    -->
</table>
