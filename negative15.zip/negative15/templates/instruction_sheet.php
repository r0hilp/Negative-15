<!--
* instruction_sheet.php
* Webpage for the instructions of the website
* Negative 15
-->

</div>
</div> <!-- End Smallcontainer and Middle Classes-->

<div class = "instructioncontainer">
	<div class = "box">
		<p >
			Welcome to Negative 15!
		<p>
			Negative 15 an innovative new way to keep track of the nutritional content of your dining hall meals to keep off that freshman fifteen, especially after Thanksgiving. 
On our home page, there are three main functions you can use. If you’re curious as to what you’ll be having at any given meal. Just click Today's menu, select a meal time, and click go. You’ll find an easy-to-navigate dropdown that has all of the options organized by food category.
Of course, the main idea is to allow users to build a nutritional profile of specifically what they’re having, and you can do that in Make a Meal. Just click the button on the homepage or in the sidebar, select the meal time, select the foods you want, enter the desired portions (these have built-in standard serving sizes), and click the confirm button to display the total nutritional profile of that meal. 
We’re planning ahead for the new year, so if it’s a goal of yours to eat healthier and cleaner, save the meal to keep a record for yourself. You can view this record in history, which displays the nutritional profile of each meal, along with what you ate, for any given date.
We hope you find the modern, flat design appealing and the pages intuitive and easy to navigate. Enjoy!
		</p>
	</div>
</div>