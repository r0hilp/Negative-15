<!--
* home.php
* Homepage. Contains buttons to all links in webpage
* Negative 15
-->

<div class="smallvspace"></div>
<div class = "box">
    <h1> Choose an Option </h1>
    <div>
        <a href="make.php"><button class="myButton">Make a meal</button></a>
    </div>
    <div class="smallvspace"></div>
    <div>
        <a href="menu.php"><button class="myButton">Today's menu</button></a>
    </div>
    <div class="smallvspace"></div>
    <div>
        <a href="history.php"><button class="myButton">Meal History</button></a>
    </div>
    <div class="smallvspace"></div>
    <div>
        <a href="instructions.php"><button class="myButton">Instructions</button></a>
    </div>
    <div class="smallvspace"></div>
    <div>
        <a href="logout.php"><button class="myButton">Log Out</button></a>
    </div>
</div>