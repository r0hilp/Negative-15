<!--
* footer.php
* Footer of the HTML
* Almost the same as PSET7, changed copyright text
* Negative 15
-->
            
            <div id="bottom" class = "text-center">
                Copyright &#169; Negative 15
            </div>
            </div>
        </div>
	</div>
</body>
</html>
