<?php
	/*
	* history_form.php
	* Prints the variable temp (stores history) to an HTML doc
	* Negative 15
	*/
	
	print($temp);
?>
