
<?php
	/*
	* make.php
	* Controller that renders the makemeal.php
	* The first page in the Make Meal sequence
	* -Negative 15
	*/

	// config
    require("../includes/config.php"); 

	render("makemeal.php");
?>
