<?php
    /*
    * menu.php
    * Controller that handles the display of the menu
    * -Negative 15
    */

    // configuration
    require("../includes/config.php"); 

    // render the form page for the menu
    render("menu_form.php");
?>
