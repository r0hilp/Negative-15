<?php
	/*
	* instructions.php
	* Controller that renders the page that has the instructions for the website
	* -Negative 15
	*/

	// config
    require("../includes/config.php"); 

    // render the page with instructions
	render("instruction_sheet.php");
?>