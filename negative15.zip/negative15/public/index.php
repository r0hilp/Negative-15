<?php
    /*
    * index.php
    * Controller that renders homepage of webpage
    * -Negative 15
    */

    // configuration
    require("../includes/config.php"); 
    
    render("home.php");  
?>
